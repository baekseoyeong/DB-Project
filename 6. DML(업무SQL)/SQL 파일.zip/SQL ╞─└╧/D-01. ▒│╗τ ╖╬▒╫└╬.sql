
-- 1. 교사 로그인

select count(*) from tblTeacher where jumin = '로그인할 교사 주민번호 뒷자리'; -- 결과값이 0이면 실패, 1이면 성공


